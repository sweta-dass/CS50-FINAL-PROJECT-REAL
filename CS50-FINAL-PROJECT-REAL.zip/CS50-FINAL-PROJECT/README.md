# Coding Girls
#### Video Demo:  <[URL HERE](https://youtu.be/4J01NlFm5Hs)>
#### Description: 
My name is Sweta Das and I am the creator of Coding Girls, a website created with HTML, CSS, and JavaScript that aims to promote sisterhood and foster a 
collaborative community by exploring the world of computer science. The home page contains a logo in the upper left, which is a heart inside a pair of curly braces. 
This was created with Canva. Located on the upper right hand side is an animated navigation bar to help users easily access the rest of the pages of my website. 
When users scroll, they are provided with these statistics from AAUW, with each of them highlighting women and their current standing in the CS workforce. 
These were also animated in order to provide users with a pleasant experience. At the bottom of the page, users are given information about 4 women and their 
remarkable contributions in the CS world. I implemented this to encourage girls who might initially be hesitant to pursue a career in STEM that there are many women, 
especially from minority backgrounds, that have completely revolutionized the world of STEM. 

The next page is the "Resources" page, which aims to provide students with helpful information to give them a kick start when thinking about coding. 
They are introduced to several of the most popular programming languages today, including Python, Java, and HTML. The image of the several logos was created in Canva.
The second element of this page is a quiz that users can take, which was created in JavaScript. It includes 10 basic questions about the overarching ideas of programming 
to help them get an idea of what it is going to be like to code as well as different terminologies they should know. When they submit the quiz, an alert 
button appears telling them their score.

The final page, "About", helps users learn more about the website creator (me) as well as some of my interests and things I've been doing in high school to explore 
CS more. I hope that this website inspires girls of all ages to give coding a try because they never know the wonderful things that can be discovered. 
